using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }
    public UIManager()
    {
        Instance = this;
    }

    [Header("Menus")]
    [SerializeField] GameObject inventoryMenu;
    [SerializeField] GameObject buildMenu;
    GameObject m_currentOpenMenu = null;
    GameObject currentOpenMenu
    {
        get
        {
            return m_currentOpenMenu;
        }
        set
        {
            if (value == null) player.Unpause();
            else player.Pause();
            m_currentOpenMenu = value;
        }
    }
    [Header("Logs")]
    [SerializeField] Transform logAnchor;
    [SerializeField] GameObject logPrefab;
    Pooler logPool;

    Player player;
    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        player.onBuildModeEnter += CloseMenu;
        player.onInspectChange += (bool inspecting) =>
        {
            CloseMenu();
        };
        logPool = new Pooler(logPrefab, 30, 0);
    }
    private void Update()
    {
        if (InputManager.Input_InventoryOpen())
        {
            OpenMenu(inventoryMenu);
        }
        if (InputManager.Input_BuildMenuOpen() && player.inspecting)
        {
            OpenMenu(buildMenu);
        }
        if (InputManager.Input_CloseTab())
        {
            CloseMenu();
        }
    }
    void OpenMenu(GameObject menu)
    {
        if(currentOpenMenu == menu) 
        {
            menu.SetActive(false);
            currentOpenMenu = null;
        }
        else
        {
            if(currentOpenMenu != null) currentOpenMenu.SetActive(false);
            menu.SetActive(true);
            currentOpenMenu = menu;
        }
    }
    public void CloseMenu()
    {
        if(currentOpenMenu != null) currentOpenMenu.SetActive(false);
        currentOpenMenu = null;
    }
    List<Log> logs = new();
    public void Log(string title, string message, Color titleColor)
    {
        if(logs.Count >= 3)
        {
            logs[0].Delete();
        }
        Log log = logPool.GetObject(logAnchor).GetComponent<Log>();
        log.Set(title, message, titleColor);
        log.onLogDelete.AddListener(() => { logs.Remove(log); logPool.ReleaseObject(log.gameObject); });
        logs.Add(log);
    }
}
