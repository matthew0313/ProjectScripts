using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "TreeSpawn Data", menuName = "Scriptables/Spawn Data/TreeSpawn Data", order = 0)]
public class TreeSpawnData : SpawnData
{

}
