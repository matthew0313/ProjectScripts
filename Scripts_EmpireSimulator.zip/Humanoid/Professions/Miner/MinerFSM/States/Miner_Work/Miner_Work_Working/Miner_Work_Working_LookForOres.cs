using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class Miner_Work_Working_LookForOres : NPC_State<Miner>
{
    public Miner_Work_Working_LookForOres(Layer parent, Miner origin) : base(parent, origin)
    {
        
    }
    public override void OnUpdate()
    {
        if (character.targetNode == null)
        {
            List<OreNode> available = new List<OreNode>();
            foreach (OreNode node in (character.workplace as Cave).nodes)
            {
                if (node.oreSpawned && node.occupant == null && (character.workGear.data as PickaxeData).tier >= node.tier)
                {
                    available.Add(node);
                }
            }
            if(available.Count > 0)
            {
                switch (character.priority)
                {
                    case Miner_OrePriority.random:
                        OreNode selected = available[Random.Range(0, available.Count)];
                        character.targetNode = selected;
                        character.targetNode.occupant = character; break;
                    case Miner_OrePriority.highTier:
                        available.Sort((OreNode a, OreNode b) => { return b.tier.CompareTo(a.tier); });
                        character.targetNode = available[0];
                        character.targetNode.occupant = character; break;
                    case Miner_OrePriority.lowTier:
                        available.Sort((OreNode a, OreNode b) => { return a.tier.CompareTo(b.tier); });
                        character.targetNode = available[0];
                        character.targetNode.occupant = character; break;

                }
                parentLayer.SwitchState("MoveToOre");
            }
        }
        else parentLayer.SwitchState("MoveToOre");
        base.OnUpdate();
    }
}
[System.Serializable] public enum Miner_OrePriority
{
    random,
    highTier,
    lowTier
}
