using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Builder : NPC
{
    public Builder() : base(500)
    {
        topLayer = new Builder_TopLayer(this);
    }
    
    public float workAmount
    {
        get { return 1.0f + (level / 25) * 1.0f; }
    }
    public override List<IWorkplace> availableJobs()
    {
        List<IWorkplace> tmp = new List<IWorkplace>();
        List<Blueprint> tmp2 = island.GetAccessibles<Blueprint>();
        foreach (Blueprint c in tmp2)
        {
            if(c!=null) tmp.Add(c);
        }
        return tmp;
    }
}
