using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;

public class NPC_Rest_Resting : NPC_State
{
    public NPC_Rest_Resting(Layer parent, NPC origin) : base(parent, origin)
    {

    }
}
