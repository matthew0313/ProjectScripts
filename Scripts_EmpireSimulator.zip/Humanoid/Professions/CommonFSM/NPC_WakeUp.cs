using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class NPC_WakeUp : NPC_State
{
    public NPC_WakeUp(Layer parent, NPC origin) : base(parent, origin)
    {

    }
    public override void OnStateEnter()
    {
        character.energy = 0;
        character.home.OnRest(character);
        List<FoodData> food = EmpireManager.Instance.Search<FoodData>();
        if (food.Count == 0)
        {
            character.energy = 10;
        }
        else
        {
            food.Sort((FoodData a, FoodData b) => a.priority.CompareTo(b.priority));
            EmpireManager.Instance.storage[food[0]]--;
            food[0].OnEat(character);
        }
        base.OnStateEnter();
    }
}
