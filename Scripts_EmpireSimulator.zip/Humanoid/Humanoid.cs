using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Humanoid : MonoBehaviour
{
    public virtual float Luck()
    {
        return 1.0f;
    }
}
