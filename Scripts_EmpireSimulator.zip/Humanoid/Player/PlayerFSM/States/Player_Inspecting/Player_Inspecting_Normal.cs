using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Inspecting_Normal : Player_State
{
    public Player_Inspecting_Normal(Layer parent, Player player) : base(parent, player)
    {
        
    }
    public override void OnUpdate()
    {
        if (player.buildMode == true) parentLayer.SwitchState("BuildMode");
        base.OnUpdate();
    }
}
