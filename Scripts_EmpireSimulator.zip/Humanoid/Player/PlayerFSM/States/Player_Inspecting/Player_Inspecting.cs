using System.Collections;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using Unity.Android.Gradle.Manifest;
using UnityEngine;

public class Player_Inspecting : Player_Layer
{
    Vector3 moveDir = Vector3.zero;
    public Player_Inspecting(Layer parent, Player player) : base(parent, player)
    {
        defaultState = new Player_Inspecting_Normal(this, player);
        AddState("Normal", defaultState);
        AddState("BuildMode", new Player_Inspecting_BuildMode(this, player));
    }
    public override void OnStateEnter()
    {
        player.inspecting = true;
        player.freeCam.Priority = 11;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        base.OnStateEnter();
    }
    public override void OnUpdate()
    {
        CameraRotation();
        Move();
        if (InputManager.Input_SwitchToInspect())
        {
            parentLayer.SwitchState("Normal");
        }
        base.OnUpdate();
    }
    public override void OnStateExit()
    {
        player.inspecting = false;
        player.freeCam.Priority = 10;
        base.OnStateExit();
    }
    void CameraRotation()
    {
        if (Input.GetMouseButton(1))
        {
            float horizontalInput = Input.GetAxis("Mouse X");
            float verticalInput = Input.GetAxis("Mouse Y");

            player.freeCam.transform.Rotate(Vector3.up, horizontalInput * player.camSensitivity, Space.World);
            player.freeCam.transform.Rotate(Vector3.right, ((player.camYReverse) ? -1.0f : 1.0f) * verticalInput * player.camSensitivity, Space.Self);
        }
    }
    void Move()
    {
        float moveX = InputManager.Input_HorizontalAxis() * player.flySpeed;
        float moveY = InputManager.Input_VerticalAxis() * player.flySpeed;
        Vector3 dir = new Vector3(moveX, 0, moveY);
        player.freeCam.transform.Translate(dir * player.flySpeed * Time.deltaTime);
        if (InputManager.Input_CameraUp())
        {
            player.freeCam.transform.position += Vector3.up * player.updownSpeed * Time.deltaTime;
        }
        if (InputManager.Input_CameraDown())
        {
            player.freeCam.transform.position += Vector3.down * player.updownSpeed * Time.deltaTime;
        }
    }
}
