using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Player_Inspecting_BuildMode : Player_State
{
    public Player_Inspecting_BuildMode(Layer parent, Player player) : base(parent, player)
    {
        
    }
    GameObject buildingModel = null;
    Structure buildingInfo = null;
    public override void OnStateEnter()
    {
        if (player.buildMode == false) parentLayer.SwitchState("Normal");
        buildingModel = MonoBehaviour.Instantiate(player.buildingStructure.gameObject);
        buildingInfo = player.buildingStructure;
        base.OnStateEnter();
    }
    public override void OnUpdate()
    {
        if (player.buildMode == false) parentLayer.SwitchState("Normal");
        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenToWorldPoint(InputManager.Input_MousePos()), Camera.main.transform.forward, out hit, player.scanDist, LayerMask.GetMask("BuildArea")))
        {
            buildingModel.transform.position = new Vector3(Mathf.RoundToInt(hit.point.x / player.gridSize) * player.gridSize, hit.transform.position.y + 1.5f, Mathf.RoundToInt(hit.point.z / player.gridSize) * player.gridSize);
            if (InputManager.Input_BuildModePlace())
            {
                foreach(ItemIntPair i in buildingInfo.ingredients)
                {
                    if (EmpireManager.Instance.Get(i.item) < i.count)
                    {
                        UIManager.Instance.Log("Unable to place", "You do not have enough ingredients to place this building.", Color.red);
                        return;
                    }
                }
                RaycastHit[] tmp = Physics.BoxCastAll(buildingModel.transform.position + new Vector3(0, 1, 0), buildingInfo.foundation.localScale * 0.5f, Vector3.down, Quaternion.identity, Mathf.Infinity, LayerMask.GetMask("Structure"));
                foreach(var i in tmp)
                {
                    if (!i.collider.transform.IsChildOf(buildingModel.transform))
                    {
                        UIManager.Instance.Log("Unable to place", "There's something in the way.", Color.red);
                        return;
                    }
                }
                foreach (ItemIntPair i in buildingInfo.ingredients)
                {
                    EmpireManager.Instance.storage[i.item] -= i.count;
                }
                Blueprint blueprint = buildingModel.GetComponent<Blueprint>();
                blueprint.island = EmpireManager.Instance.currentIsland;
                EmpireManager.Instance.currentIsland.accessibles.Add(blueprint);
                buildingModel = null;
                if (InputManager.Input_BuildModeContinue())
                {
                    OnStateEnter();
                }
                else
                {
                    player.ExitBuildMode();
                    parentLayer.SwitchState("Normal");
                }
            }
        }
        if (InputManager.Input_ExitBuildMode())
        {
            player.ExitBuildMode();
            parentLayer.SwitchState("Normal");
        }
        base.OnUpdate();
    }
    public override void OnStateExit()
    {
        if (buildingModel != null) MonoBehaviour.Destroy(buildingModel);
        base.OnStateExit();
    }
}
