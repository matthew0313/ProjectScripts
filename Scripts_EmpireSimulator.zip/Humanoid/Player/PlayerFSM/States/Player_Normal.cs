using System.Collections;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using Unity.Android.Gradle.Manifest;
using UnityEngine;
using Cinemachine;
using System.Net.NetworkInformation;

public class Player_Normal : Player_State
{
    Vector3 moveDir = Vector3.zero;
    public Player_Normal(Layer parent, Player player) : base(parent, player)
    {

    }
    public override void OnStateEnter()
    {
        player.normalCam.Priority = 11;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        base.OnStateEnter();
    }
    public override void OnUpdate()
    {
        CameraRotation();
        Move();
        if (InputManager.Input_SwitchToInspect())
        {
            parentLayer.SwitchState("Inspecting");
        }
        base.OnUpdate();
    }
    public override void OnStateExit()
    {
        player.normalCam.Priority = 10;
        base.OnStateExit();
    }
    void CameraRotation()
    {
        if (Input.GetMouseButton(1))
        {
            float horizontalInput = Input.GetAxis("Mouse X");
            float verticalInput = Input.GetAxis("Mouse Y");

            player.transform.Rotate(Vector3.up, horizontalInput * player.camSensitivity, Space.World);
            player.camAnchor.transform.Rotate(Vector3.right, ((player.camYReverse) ? -1.0f : 1.0f) * verticalInput * player.camSensitivity, Space.Self);
        }
    }
    void Move()
    {
        float moveX = (InputManager.Input_IsRunning() ? player.runSpeed : player.moveSpeed) * InputManager.Input_HorizontalAxis();
        float moveY = (InputManager.Input_IsRunning() ? player.runSpeed : player.moveSpeed) * InputManager.Input_VerticalAxis();
        float prevY = moveDir.y;
        moveDir = (moveX * player.transform.TransformDirection(Vector3.right)) + (moveY * player.transform.TransformDirection(Vector3.forward));
        if (InputManager.Input_Jump() && player.controller.isGrounded)
        {
            moveDir.y = player.jumpPower;
        }
        else
        {
            moveDir.y = prevY;
        }
        if(player.controller.isGrounded == false)
        {
            moveDir.y -= player.gravity * Time.deltaTime;
        }
        player.controller.Move(moveDir * Time.deltaTime);
    }
}
