using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClaimableIsland : Island
{
    public List<Accessibles> accessibles = new List<Accessibles>();
    
    public List<T> GetAccessibles<T>() where T : Accessibles
    {
        List<T> list = new List<T>();
        for(int i = 0; i < accessibles.Count; i++)
        {
            if (accessibles[i] == null) accessibles.RemoveAt(i);
            else if (typeof(T).IsAssignableFrom(accessibles[i].GetType()))
            {
                list.Add(accessibles[i] as T);
            }
        }
        return list;
    }
}
