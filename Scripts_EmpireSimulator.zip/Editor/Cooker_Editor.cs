using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
[CustomEditor(typeof(Cooker))]
public class Cooker_Editor : NPC_Editor<Cooker>
{

}
