using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
[CustomEditor(typeof(Smelter))]
public class Smelter_Editor : NPC_Editor<Smelter>
{

}
