using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;
[CustomEditor(typeof(Lumberjack))]
public class Lumberjack_Editor : NPC_Editor<Lumberjack>
{

}
