using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using Unity.Profiling;
using UnityEngine;
using UnityEngine.Events;

public class InputManager : MonoBehaviour
{
    public static float Input_HorizontalAxis()
    {
        return Input.GetAxis("Horizontal");
    }
    public static float Input_VerticalAxis()
    {
        return Input.GetAxis("Vertical");
    }
    public static bool Input_IsRunning()
    {
        return Input.GetKey(KeyCode.LeftShift);
    }
    public static bool Input_Jump()
    {
        return Input.GetKeyDown(KeyCode.Space);
    }
    public static bool Input_SwitchToInspect()
    {
        return Input.GetKeyDown(KeyCode.F);
    }
    public static bool Input_CameraUp()
    {
        return Input.GetKey(KeyCode.E);
    }
    public static bool Input_CameraDown()
    {
        return Input.GetKey(KeyCode.Q);
    }
    public static bool Input_InventoryOpen()
    {
        return Input.GetKeyDown(KeyCode.E);
    }
    public static bool Input_BuildMenuOpen()
    {
        return Input.GetKeyDown(KeyCode.Tab);
    }
    public static bool Input_CloseTab()
    {
        return Input.GetKeyDown(KeyCode.Escape);
    }
    public static bool Input_ExitBuildMode()
    {
        return Input.GetKeyDown(KeyCode.B);
    }
    public static bool Input_BuildModePlace()
    {
        return Input.GetMouseButtonDown(0);
    }
    public static Vector3 Input_MousePos()
    {
        return Input.mousePosition;
    }
    public static bool Input_BuildModeContinue()
    {
        return Input.GetKey(KeyCode.LeftShift);
    }
}
