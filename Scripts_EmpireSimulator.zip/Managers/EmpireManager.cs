using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Pool;

public class EmpireManager : MonoBehaviour
{
    public static EmpireManager Instance { get; private set; }
    public EmpireManager()
    {
        Instance = this;
    }

    public List<ClaimableIsland> claimedIslands = new List<ClaimableIsland>();
    public ClaimableIsland currentIsland;

    //time
    public int hour = 6;
    const float hourTime = 10.0f;
    [SerializeField] float counter = 0.0f;

    //schedule
    public static int workStart = 7;
    public static int workEnd = 22;

    //storage
    public Dictionary<ItemData, int> storage = new Dictionary<ItemData, int>();
    [SerializeField] ItemData addingItem;
    [SerializeField] int addAmount;
    [SerializeField] ItemIntPair[] startingStorage;

    //Events
    public UnityEvent newdayStart = new UnityEvent();

    //Statistics
    public float npcDamageMultiplier { get; private set; } = 1.0f;
    public float npcWorkMultiplier { get; private set; } = 1.0f;
    [SerializeField] GameObject[] startingStructures;
    public List<Structure> unlockedStructures { get; } = new();

    public delegate void StructureUnlockCallback(Structure structure);
    public event StructureUnlockCallback onStructureUnlock;
    
    private void Awake()
    {
        onStorageAdd += (ItemData item, int count) => { Debug.Log("Added " + count + " " + item.name); };
        foreach(var i in startingStorage)
        {
            AddItemToStorage(i);
        }
    }
    private void Start()
    {
        foreach (var i in startingStructures) UnlockStructure(i);
    }
    public void UnlockStructure(GameObject structurePrefab)
    {
        Structure tmp = Instantiate(structurePrefab, new Vector3(0.0f, -1000.0f, 0.0f), Quaternion.identity).GetComponent<Structure>();
        unlockedStructures.Add(tmp);
        onStructureUnlock.Invoke(tmp);
    }

    #region StorageFunctions
    public List<T> Search<T>() where T : ItemData
    {
        List<T> list = new List<T>();
        foreach (ItemData item in storage.Keys)
        {
            if (typeof(T).IsAssignableFrom(item.GetType()) && storage[item] > 0)
            {
                list.Add(item as T);
            }
        }
        return list;
    }
    public int Get(ItemData item)
    {
        if (!storage.ContainsKey(item)) return 0;
        else return storage[item];
    }
    public void AddToStorage()
    {
        AddItemToStorage(new ItemIntPair(addingItem, addAmount));
    }
    public void AddItemToStorage(List<ItemIntPair> add)
    {
        foreach (ItemIntPair i in add)
        {
            AddItemToStorage(i);
        }
    }
    public delegate void StorageAddCallbacks(ItemData addedItem, int addedAmount);
    public event StorageAddCallbacks onStorageAdd;
    public void AddItemToStorage(ItemIntPair add)
    {
        if (storage.ContainsKey(add.item))
        {
            storage[add.item] += add.count;
        }
        else
        {
            storage.Add(add.item, add.count);
        }
        onStorageAdd.Invoke(add.item, add.count);
    }

    #endregion

    private void Update()
    {
        if (counter < hourTime) counter += Time.deltaTime;
        else
        {
            PassHour();
        }
    }
    public void PassHour()
    {
        if (++hour == 24)
        {
            hour = 0;
            newdayStart.Invoke();
        }
        counter = 0.0f;
    }
    public void SubtractHour()
    {
        if (--hour < 0) hour = 0;
        counter = 0.0f;
    }
}
