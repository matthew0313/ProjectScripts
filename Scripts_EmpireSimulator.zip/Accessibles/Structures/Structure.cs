using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Structure : Accessibles
{
    public string Name;
    [TextArea] public string Description;

    public Transform foundation;
    public List<ItemIntPair> ingredients = new List<ItemIntPair>();
    public int cost;

    public virtual string Describe()
    {
        return Description;
    }
}
