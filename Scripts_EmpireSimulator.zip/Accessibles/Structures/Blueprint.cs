using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Structure))]
public class Blueprint : Accessibles, IProgressiveWork
{
    #region interface variables
    public Transform workplace_Marker
    {
        get { return m_workplace_Marker; }
        set { }
    }
    public List<NPC> workers
    {
        get { return m_workers; }
        set { m_workers = value; }
    }
    [SerializeField] Transform m_workplace_Marker;
    [SerializeField] List<NPC> m_workers;
    
    public float requiredWorkAmount
    {
        get { return m_requiredWorkAmount; }
    }
    public float workedAmount
    {
        get { return m_workedAmount; }
        set { m_workedAmount = value; }

    }
    [SerializeField] float m_requiredWorkAmount;
    [SerializeField] float m_workedAmount;
    #endregion

    public string Name { get { return origin.Name; } }
    public ClaimableIsland island;
    [SerializeField] GameObject buildingModel;
    Structure origin;

    public int experienceGiven;
    void Awake()
    {
        origin = GetComponent<Structure>();
        origin.enabled = false;
        buildingModel.SetActive(false);
    }
    void OnDestroy()
    {

    }
    public void OnWorkFinish(Humanoid worker)
    {
        foreach (NPC i in workers)
        {
            i.GetExperience(experienceGiven);
            i.workplace = null;
        }
        origin.enabled = true;
        island.accessibles.Add(origin);
        buildingModel.SetActive(true);
        Object.Destroy(this);
    }
}
