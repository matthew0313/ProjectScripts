using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MenuManager : MonoBehaviour
{
    public GameObject BuildMenu;
    public Transform[] tabs = new Transform[6];
    int[] buttons = new int[6];
    public GameObject buildButton;
    private void Start()
    {
        foreach(GameObject i in GameManager.instance.availableBlueprints)
        {
            CreateButton(i);
        }
    }
    public void CreateButton(GameObject i)
    {
        int cat = (int)i.GetComponent<Blueprint>().category;
        GameObject a = Instantiate(buildButton, tabs[cat]);
        a.transform.localPosition = new Vector2(-940.0f + (110.0f * (buttons[cat] % 15)), 65.0f - (110.0f * (buttons[cat] / 15)));
        buttons[cat]++;
        GameObject b = i;
        a.GetComponent<Button>().onClick.AddListener(() => { GameManager.instance.BuildMode(b); });
        a.transform.GetChild(0).GetComponent<Text>().text = b.GetComponent<Blueprint>().Name;
    }
    public void TurnOnTab(int num)
    {
        foreach(Transform t in tabs)
        {
            t.gameObject.SetActive(false);
        }
        tabs[num].gameObject.SetActive(true);
    }
    public void BuildMenuToggle(bool on)
    {
        if (on) TabManager.AddTab(BuildMenu);
        else BuildMenu.SetActive(false);
    }
}
