using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Mode
{
    public UnityEvent onSwitch = new UnityEvent();
    public virtual void Update()
    {

    }
    public virtual void OnSwitch()
    {
        onSwitch.Invoke();
    }
    public virtual void OnExit()
    {

    }
}
