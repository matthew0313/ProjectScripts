using System.Collections;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class InspectMode : Mode
{
    public override void OnSwitch()
    {
        base.OnSwitch();
    }
    public override void OnExit()
    {
        base.OnExit();
        GameManager.instance.chosen = null;
    }
    public override void Update()
    {
        base.Update();
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero, 1.0f, GameManager.instance.whatToHit);
            if(hit && hit.transform.tag == "Interactable")
            {
                InteractableObject a = hit.transform.GetComponent<InteractableObject>();
                GameManager.instance.SetInspector(a);
            }
            else
            {
                GameManager.instance.HideInspector();
            }
            Debug.Log(hit.transform.tag);
        }
    }
}
