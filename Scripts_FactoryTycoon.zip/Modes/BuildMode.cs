using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class BuildMode : Mode
{
    public GameObject buildingObject;
    public Blueprint dragObject;
    public LayerMask whatToHit;
    BoxCollider2D collideArea;
    public override void OnSwitch()
    {
        base.OnSwitch();
        TabManager.HideAllTab();
        TabManager.canEditTab = false;
        dragObject = MonoBehaviour.Instantiate(buildingObject).GetComponent<Blueprint>();
        collideArea = dragObject.GetComponent<Blueprint>().boxCollider;
    }
    public override void OnExit()
    {
        base.OnExit();
        TabManager.ShowAllTab();
        TabManager.canEditTab = true;
        if (dragObject != null) MonoBehaviour.Destroy(dragObject);
    }
    public override void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            GameManager.instance.ExitMode();
            return;
        }
        Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        dragObject.transform.position = new Vector3(Mathf.Round(pos.x/0.25f)*0.25f, Mathf.Round(pos.y/0.25f)*0.25f, 0.0f);
        RaycastHit2D[] hit = Physics2D.BoxCastAll(dragObject.transform.position, collideArea.size * 0.95f, 0.0f, Vector2.right, whatToHit);
        bool occupied = false, hasResource = (dragObject..requiredResource == ResourceNodeType.none);
        for(int i = 0; i < hit.Length; i++)
        {
            if (hit[i].transform == dragObject.transform) continue;
            if (hit[i].transform.gameObject.layer == 7) occupied = true;
            else if(hit[i].transform.gameObject.layer == 6)
            {
                if (hit[i].transform.GetComponent<ResourceNode>().nodeType == dragObject.requiredResource)
                {
                    hasResource = true;
                }
            }
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (!occupied && hasResource)
            {
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    dragObject = MonoBehaviour.Instantiate(buildingObject, pos, Quaternion.identity).GetComponent<Blueprint>();
                }
                else
                {
                    buildingObject = null;
                    dragObject = null;
                    GameManager.instance.ChangeMode(null);
                }
            }
            else if (occupied)
            {
                LogManager.instance.Log("Something is in the way.", new Color32(255, 0, 0, 255));
            }
            else if (!hasResource)
            {
                LogManager.instance.Log("This building requires " + dragObject.requiredResource.ToString() + " nearby.", new Color32(255, 125, 0, 255));
            }
        }
    }
}
