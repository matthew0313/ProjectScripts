using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEditor;
using UnityEngine;

[RequireComponent(typeof(BlueprintInput))]public class Blueprint : MonoBehaviour
{
    [Header("Construction")][InspectorName("Ingredients")] public BlueprintIngredientInspector[] m_ingredients;
    public Dictionary<ItemData, BlueprintIngredient> ingredients = new Dictionary<ItemData, BlueprintIngredient>();

    [Header("Building Object")] public Building building;
    public BuildingData data { get { return building.data; } }

    [Header("Components")] public BlueprintInput input;
    public BoxCollider2D boxCollider { get { return building.collider; } }
    void Awake()
    {
        input = GetComponent<BlueprintInput>();
        for (int i = 0; i < m_ingredients.Length; i++)
        {
            BlueprintIngredient a = new BlueprintIngredient(m_ingredients[i].required, m_ingredients[i].part);
            ingredients.Add(m_ingredients[i].item, a);
            input.inputItems.Add(m_ingredients[i].item);
        }
    }
    public void InsertIngredient(ItemData item, int amount)
    {
        ingredients[item].contains += amount;
        if (ingredients[item].FullCheck())
        {
            ConstructionCheck();
        }
    }
    void ConstructionCheck()
    {
        bool full = true;
        foreach(BlueprintIngredient i in ingredients.Values)
        {
            if (!i.met)
            {
                full = false;
                break;
            }
        }
        if (full)
        {
            Construct();
        }
    }
    public void Construct()
    {
        Instantiate(building.gameObject, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }
    [Header("Debug")] public bool forcedConstruct = false;
    private void OnValidate()
    {
        if (forcedConstruct) Construct();
    }
}
[System.Serializable]
public enum BuildingCategory
{
    resource,
    process,
    transport,
    storage,
    research,
    utility
}
[System.Serializable] public class BlueprintIngredient
{
    public BlueprintIngredient(int req, GameObject p)
    {
        required = req;
        part = p;
        if(part!=null) part.SetActive(false);
    }
    public int required;
    public int contains = 0;
    public GameObject part;
    public bool met = false;
    public bool FullCheck()
    {
        if (contains >= required)
        {
            met = true;
            if(part!=null) part.SetActive(false);
            return true;
        }
        return false;
    }
}
[System.Serializable] public class BlueprintIngredientInspector
{
    public ItemData item;
    public int required;
    public GameObject part;
}