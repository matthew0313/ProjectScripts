using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]public class Building : MonoBehaviour
{
    public BuildingData data;
    [HideInInspector] public BoxCollider2D collider;

    public bool shutdown = false;

    [Space(5)] public bool sellable = true;
    private void Awake()
    {
        collider = GetComponent<BoxCollider2D>();
    }
    private void Start()
    {
        ElectricityManager.instance.consuption += data.consuption;
        ElectricityManager.instance.shutdown.AddListener(Shutdown);
        ElectricityManager.instance.reboot.AddListener(Reboot);
    }
    void Shutdown()
    {
        shutdown = true;
    }
    void Reboot()
    {
        shutdown = false;
    }
}
