using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ItemStorage))]public class ItemGeneration : Operator
{
    [SerializeField] ItemStorage storage;
    [SerializeField] ItemData generatedItem;
    [SerializeField] int generateAmount;
    // Start is called before the first frame update
    void Start()
    {
        storage = GetComponent<ItemStorage>();
        storage.displayItems.Add(generatedItem);
    }

    // Update is called once per frame
    public override void Operate()
    {
        base.Operate();
        storage.AddItem(generatedItem, Mathf.Min(generateAmount, storage.capacity - storage.Check(generatedItem)));
    }
}
