using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ItemStorage))]public class ItemProcess : Operator
{
    [SerializeField] ItemStorage storage;
    [SerializeField] Recipe chosenRecipe = null;
    [SerializeField] Recipe[] availableRecipes;
    void Start()
    {
        storage = GetComponent<ItemStorage>();
    }
    public void RecipeSelect(Recipe recipe)
    {
        if (chosenRecipe != null)
        {
            for (int i = 0; i < chosenRecipe.ingredient.Length; i++)
            {
                storage.DisplayRemove(chosenRecipe.ingredient[i].item);
            }
            for (int i = 0; i < chosenRecipe.results.Length; i++)
            {
                storage.DisplayRemove(chosenRecipe.results[i].item);
            }
        }
        chosenRecipe = recipe;
        for(int i = 0; i < recipe.ingredient.Length; i++)
        {
            storage.DisplayAdd(recipe.ingredient[i].item);
        }
        for (int i = 0; i < recipe.results.Length; i++)
        {
            storage.DisplayAdd(recipe.ingredient[i].item);
        }
    }
    public override void Operate()
    {
        base.Operate();
        if (chosenRecipe == null)
        {
            return;
        }
        bool hasAll = true;
        for(int i = 0; i < chosenRecipe.ingredient.Length; i++)
        {
            if (storage.Check(chosenRecipe.ingredient[i].item) < chosenRecipe.ingredient[i].count)
            {
                hasAll = false;
                break;
            }
        }
        bool hasRoom = true;
        for(int i = 0; i < chosenRecipe.results.Length; i++)
        {
            if (storage.capacity - storage.Check(chosenRecipe.results[i].item) < chosenRecipe.results[i].count)
            {
                hasRoom = false;
                break;
            }
        }
        if (hasAll && hasRoom)
        {
            storage.AddItem(chosenRecipe.results, 1);
            for(int i = 0; i < chosenRecipe.ingredient.Length; i++)
            {
                storage.contents[chosenRecipe.ingredient[i].item] -= chosenRecipe.ingredient[i].count;
            }
        }
    }
}
[System.Serializable] public struct ItemIntPair
{
    public ItemData item;
    public int count;
}
[System.Serializable] public class Recipe
{
    public ItemIntPair[] ingredient, results;
}
