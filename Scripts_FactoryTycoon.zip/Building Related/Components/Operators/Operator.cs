using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Building))]public class Operator : MonoBehaviour
{
    Building origin;
    [SerializeField] public float operateTime;
    float counter = 0.0f;
    private void Awake()
    {
        origin = GetComponent<Building>();
    }
    private void Update()
    {
        if(origin.shutdown == false)
        {
            counter += Time.deltaTime;
            if(counter > operateTime) 
            {
                counter = 0.0f;
                Operate();
            }
        }
    }
    public virtual void Operate()
    {

    }
}
