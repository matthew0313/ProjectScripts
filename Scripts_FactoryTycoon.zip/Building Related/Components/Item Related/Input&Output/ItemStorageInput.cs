using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[RequireComponent(typeof(ItemStorage))]public class ItemStorageInput : IInput
{
    ItemStorage storage;
    private void Start()
    {
        storage = GetComponent<ItemStorage>();
        storage.DisplayAdd(inputItems);
    }
    public override void Insert(ItemData item, int amount)
    {
        base.Insert(item, amount);
        storage.AddItem(item, amount);
    }
    public override int Available(ItemData item)
    {
        return storage.capacity - storage.Check(item);
    }
}
