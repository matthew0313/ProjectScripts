using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[RequireComponent(typeof(Blueprint))]public class BlueprintInput : IInput
{
    Blueprint blueprint;
    private void Start()
    {
        blueprint = GetComponent<Blueprint>();
    }
    public override void Insert(ItemData item, int amount)
    {
        blueprint.InsertIngredient(item, amount);
    }
    public override int Available(ItemData item)
    {
        return blueprint.ingredients[item].required - blueprint.ingredients[item].contains;
    }
}
