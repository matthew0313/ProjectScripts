using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[RequireComponent(typeof(ItemStorage))]public class ItemStorageOutput : Output
{
    ItemStorage storage;
    private void Start()
    {
        storage = GetComponent<ItemStorage>();
        storage.DisplayAdd(outputItems);
    }
    public override int Takeout(ItemData data, int amount)
    {
        if (storage.contents.ContainsKey(data) == false) return 0;
        int tmp = Mathf.Min(storage.contents[data], amount);
        storage.contents[data] -= tmp;
        return tmp;
    }
}
