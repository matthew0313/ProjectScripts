using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor.Search;
using UnityEngine;
using static UnityEditor.Progress;

public class ItemStorage : Storage
{
    public Dictionary<ItemData, int> contents = new Dictionary<ItemData, int>();
    public List<ItemData> displayItems = new List<ItemData>();
    public int capacity = 300;
    public int Check(ItemData item)
    {
        if (contents.ContainsKey(item))
        {
            return contents[item];
        }
        else return 0;
    }
    public void AddItem(ItemData item, int amount)
    {
        if (contents.ContainsKey(item))
        {
            contents[item] += amount;
        }
        else
        {
            contents.Add(item, amount);
        }
    }
    public void DisplayAdd(ItemData item)
    {
        if (!displayItems.Contains(item)) displayItems.Add(item);
    }
    public void DisplayAdd(List<ItemData> items)
    {
        for(int i = 0; i < items.Count; i++)
        {
            if (!displayItems.Contains(items[i])) displayItems.Add(items[i]);
        }
    }
    public void DisplayRemove(ItemData item)
    {
        if (displayItems.Contains(item)) displayItems.Remove(item);
    }
    /*public void AddItem(ItemData item)
    {
        contents.Add(item, 0);
    }
    public void AddItem(ItemData[] item)
    {
        for(int i = 0; i < item.Length; i++)
        {
            if (contents.ContainsKey(item[i])) continue;
            contents.Add(item[i], 0);
        }
    }
    public void AddItem(List<ItemData> item)
    {
        for (int i = 0; i < item.Count; i++)
        {
            if (contents.ContainsKey(item[i])) continue;
            contents.Add(item[i], 0);
        }
    }
    public void AddItem(ItemIntPair[] item)
    {
        for (int i = 0; i < item.Length; i++)
        {
            if (contents.ContainsKey(item[i].item)) continue;
            contents.Add(item[i].item, 0);
        }
    }*/
    public void AddItem(ItemIntPair[] item, int count)
    {
        for (int i = 0; i < item.Length; i++)
        {
            if (contents.ContainsKey(item[i].item))
            {
                contents[item[i].item] += item[i].count * count;
            }
            else contents.Add(item[i].item, item[i].count * count);
        }
    }
}
