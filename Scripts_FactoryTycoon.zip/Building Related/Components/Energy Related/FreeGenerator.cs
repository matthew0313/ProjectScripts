using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class FreeGenerator : Generator
{
    private void Start()
    {
        ElectricityManager.instance.generation += generation;
    }
    private void OnDestroy()
    {
        ElectricityManager.instance.generation -= generation;
    }
}
