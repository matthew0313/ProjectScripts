using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[RequireComponent(typeof(ItemStorage), typeof(ItemStorageInput))]public class FuelGenerator : Generator
{
    public ItemData requiredItem;
    public float fuelDuration;
    float counter = 0.0f;
    bool generating = false;
    ItemStorage storage;
    ItemStorageInput input;
    private void Start()
    {
        storage = GetComponent<ItemStorage>();
        input = GetComponent<ItemStorageInput>();
        input.inputItems.Add(requiredItem);
        storage.AddItem(requiredItem, 0);
    }
    private void Update()
    {
        if (counter > 0.0f) counter -= Time.deltaTime;
        if(counter <= 0.0f)
        {
            if (storage.contents[requiredItem] == 0)
            {
                if (generating)
                {
                    ElectricityManager.instance.generation -= generation;
                    generating = false;
                }
            }
            else
            {
                storage.contents[requiredItem]--;
                counter = fuelDuration;
                if (!generating)
                {
                    ElectricityManager.instance.generation += generation;
                    generating = true;
                }
            }
        }
    }
    private void OnDestroy()
    {
       if(generating) ElectricityManager.instance.generation -= generation;
    }
}
