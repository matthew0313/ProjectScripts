using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class Generator : MonoBehaviour
{
    public float generation;
}
