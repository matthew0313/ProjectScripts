using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class IInput : MonoBehaviour
{
    public List<TransportLane> lanes = new List<TransportLane>();
    public List<ItemData> inputItems = new List<ItemData>();
    public virtual void Insert(ItemData item, int amount)
    {

    }
    public virtual int Available(ItemData item)
    {
        return 0;
    }
    private void OnDestroy()
    {
        foreach(TransportLane lane in lanes)
        {
            lane.takeFrom.RemoveLane(lane);
        }
    }
}
