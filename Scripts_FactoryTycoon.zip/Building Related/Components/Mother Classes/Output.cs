using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class Output : MonoBehaviour
{
    protected List<TransportLane> lanes = new List<TransportLane>();
    public List<ItemData> outputItems = new List<ItemData>();

    public virtual int Takeout(ItemData data, int amount)
    {
        return -1;
    }
    public void CreateLane(IInput insertTo, ItemData item)
    {
        TransportLane newLane = new TransportLane(this, insertTo, item);
        lanes.Add(newLane);
    }
    public void RemoveLane(TransportLane lane)
    {
        if (lanes.Contains(lane) == false)
        {
            Debug.LogError("The lane is not in this output!");
            return;
        }
        lanes.Remove(lane);
        Destroy(lane);
    }
}
public class TransportLane : MonoBehaviour
{
    const float transportTick = 1.0f;
    float tmp = 0.0f;

    public Output takeFrom;
    public IInput insertTo;
    public ItemData item;

    public class RobotCount
    {
        public RobotData data;
        public int count;
    }
    public List<RobotCount> robots;
    public TransportLane(Output take, IInput into, ItemData it)
    {
        takeFrom = take;
        insertTo = into;
        insertTo.lanes.Add(this);
        item = it;
    }
    private void OnDestroy()
    {
        for (int i = 0; i < robots.Count; i++)
        {
            ElectricityManager.instance.ChangeConsuption(robots[i].data.energyRequired * robots[i].count);
        }
        insertTo.lanes.Remove(this);
    }
    private void Update()
    {
        tmp += Time.deltaTime;
        if (tmp > transportTick)
        {
            tmp = 0.0f;
            Transport();
        }
    }
    void Transport()
    {
        for(int i = 0; i < robots.Count; i++)
        {
            insertTo.Insert(item, takeFrom.Takeout(item, Mathf.Min(robots[i].data.transportCount * robots[i].count, insertTo.Available(item))));
        }
    }
    public void AddRobot(RobotData robot, int count)
    {
        bool contains = false;
        for(int i = 0; i <= robots.Count; i++)
        {
            if (robots[i].data == robot)
            {
                contains = true;
                robots[i].count += count;
            }
        }
        if (!contains)
        {
            RobotCount tmp = new RobotCount();
            tmp.data = robot;
            tmp.count = count;
            robots.Add(tmp);
        }
        ElectricityManager.instance.ChangeConsuption(-1 * robot.energyRequired * count);
    }
}
