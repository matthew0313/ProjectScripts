using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceNode : MonoBehaviour
{
    public ResourceNodeType nodeType;
}
[System.Serializable] public enum ResourceNodeType
{
    none,
    copper
}