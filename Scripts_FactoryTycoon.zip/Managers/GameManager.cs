using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using static SerializableDictionary;
using static UnityEngine.EventSystems.EventTrigger;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [SerializeField] int m_money = 500;
    public int money { get { return m_money; } set
        {
            m_money = value;
            moneyText.text = m_money.ToString();
        } }
    [SerializeField] Text moneyText;

    [Header("Mode")]public Mode currentMode;
    public BuildMode buildMode = new BuildMode();
    public InspectMode inspectMode = new InspectMode();

    [Header("Buildings Available")] public List<GameObject> availableBlueprints;

    [Header("UI Related")] public GameObject openTab;

    [Header("Debug")] public bool debugMode = false;

    [Header("Inspection")]
    public LayerMask whatToHit;
    [SerializeField] GameObject inspector;
    [SerializeField] GameObject sell, inspect, storage, lanes, recipes;

    public Building chosen = null;

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else instance = this;
        moneyText.text = m_money.ToString();
        ChangeMode(inspectMode);
    }
    private void Update()
    {
        if (currentMode != null) currentMode.Update();
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TabManager.CloseTopTab();
        }
    }
    public void BuildMode(GameObject buildObject)
    {
        buildMode.buildingObject = buildObject;
        ChangeMode(buildMode);
    }
    public void ChangeMode(Mode mode)
    {
        if (currentMode != null) currentMode.OnExit();
        currentMode = mode;
        mode.OnSwitch();
    }
    public void ExitMode()
    {
        if (currentMode != inspectMode)
        {
            currentMode.OnExit();
            currentMode = inspectMode;
            currentMode.OnSwitch();
        }
    }
    public void SetInspector(InteractableObject a)
    {
        int count = 0;
        void Set(GameObject obj)
        {
            sell.transform.localPosition = new Vector2(0.0f, -30.0f + 30.0f * count);
            count++;
        }
        inspector.transform.position = Input.mousePosition;
        InteractableOptions options = a.options();
        RectTransform b = inspector.transform.GetChild(0).GetComponent<RectTransform>();
        b.localScale = new Vector2(b.localScale.x, 5.0f+30.0f*options.Count());
        if (options.sell)
        {
            Set(sell);
        }
        if (options.inspect)
        {
            Set(inspect);
        }
        if (options.storage)
        {
            Set(storage);
        }
        if (options.lanes)
        {
            Set(lanes);
        }
        if (options.recipes)
        {
            Set(recipes);
        }
        inspector.SetActive(true);
    }
    public void HideInspector()
    {
        inspector.SetActive(false);
    }
}
