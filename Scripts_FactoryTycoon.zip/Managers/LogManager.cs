using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class LogManager : MonoBehaviour
{
    public static LogManager instance;
    [SerializeField] Transform logPos;
    [SerializeField] GameObject log;
    [SerializeField] List<GameObject> logList;
    const float dist = 20.0f;
    const float duration = 3.0f;
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else instance = this;
    }
    public void Log(string content, Color32 color)
    {
        GameObject a;
        if (logList.Count==0 || logList[logList.Count - 1].activeSelf)
        {
            a = Instantiate(log, logPos);
        }
        else
        {
            a = logList[logList.Count - 1];
            a.SetActive(true);
            logList.Remove(a);
        }
        logList.Insert(0, a);
        a.transform.localPosition = Vector2.zero;
        for(int i = 1; i < logList.Count; i++)
        {
            if (logList[i].activeSelf) logList[i].transform.localPosition = new Vector2(0.0f, logList[i].transform.localPosition.y + dist);
        }
        Text b = a.GetComponent<Text>();
        b.text = content;
        b.color = color;
        StartCoroutine(Dissolve(a));
    }
    IEnumerator Dissolve(GameObject obj)
    {
        yield return new WaitForSeconds(duration);
        obj.SetActive(false);
    }
}
