using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TabManager : MonoBehaviour
{
    public static List<GameObject> openTabs = new List<GameObject>();
    public static bool canEditTab = true;
    public static void AddTab(GameObject tab)
    {
        if (!canEditTab) return;
        openTabs.Insert(0, tab);
    }
    public static void CloseTopTab()
    {
        if (!canEditTab) return;
        if (openTabs.Count > 0)
        {
            openTabs[0].SetActive(false);
            openTabs.Remove(openTabs[0]);
        }
    }
    public static void CloseAllTab()
    {
        if (!canEditTab) return;
        int e = openTabs.Count;
        for(int i = 0; i < e; i++)
        {
            CloseTopTab();
        }
    }
    public static void CloseTab(GameObject tab)
    {
        if (!canEditTab) return;
        if (openTabs.Contains(tab)) openTabs.Remove(tab);
    }
    public static void HideAllTab()
    {
        for(int i = 0; i < openTabs.Count; i++)
        {
            openTabs[i].SetActive(false);
        }
    }
    public static void ShowAllTab()
    {
        for(int i = 0; i < openTabs.Count; i++)
        {
            openTabs[i].SetActive(true);
        }
    }
}
