using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class ElectricityManager : MonoBehaviour
{
    public static ElectricityManager instance;

    const float updateTick = 1.0f;
    float counter = 0.0f;

    public float storedE, maxE;
    public float consuption = 0.0f;
    public float generation = 0.0f;

    public UnityEvent shutdown;
    public UnityEvent reboot;

    [Space(5)][SerializeField] Text energyText;
    [SerializeField] Color32 idleColor, emptyColor, fullColor;

    [Space(5)][SerializeField] Text consuptionText;
    [SerializeField] Color32 zeroColor, minusColor, plusColor;
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else instance = this;
        EnergyTextUpdate();
        ConsuptionTextUpdate();
    }
    private void Update()
    {
        counter += Time.deltaTime;
        if (counter > updateTick)
        {
            counter = 0.0f;
            storedE += generation - consuption;
            if(storedE < 0.0f)
            {
                storedE = 0.0f;
                shutdown.Invoke();
            }
            if (storedE > maxE) storedE = maxE;
            EnergyTextUpdate();
        }
    }
    public void Reboot()
    {
        reboot.Invoke();
    }
    public void ChangeConsuption(float value)
    {
        if (value < 0.0f)
        {
            consuption += value;
        }
        else if (value > 0.0f)
        {
            generation += value;
        }
        ConsuptionTextUpdate();
    }
    void EnergyTextUpdate()
    {
        energyText.text = Mathf.Round(storedE) + "/" + Mathf.Round(maxE) + "E";
        if(storedE == 0)
        {
            energyText.color = emptyColor;
        }
        else if(storedE == maxE)
        {
            energyText.color = fullColor;
        }
        else
        {
            energyText.color = idleColor;
        }
    }
    void ConsuptionTextUpdate()
    {
        consuptionText.text = ((consuption<=generation) ? "+" : "") + Mathf.Round(generation-consuption) + "/sec";
        if (consuption < generation)
        {
            consuptionText.color = plusColor;
        }
        else if (consuption > generation)
        {
            consuptionText.color = minusColor;
        }
        else
        {
            consuptionText.color = zeroColor;
        }
    }
}
