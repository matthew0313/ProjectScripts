using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "ItemData", menuName = "Scriptables/Item Data", order = 0)]public class ItemData : ScriptableObject
{
    [SerializeField] string m_name;
    [SerializeField] float m_value;
    [SerializeField] Sprite m_image;
    public string Name { get { return m_name; } }
    public float value { get { return m_value; } }
    public Sprite image { get { return m_image; } }
}
