using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "BuildingData", menuName = "Scriptables/Building Data", order = 0)]public class BuildingData : ScriptableObject
{
    [Header("Default")][SerializeField] string m_name;
    [SerializeField][TextArea] string m_description;
    [SerializeField] BuildingCategory m_category;
    [Header("Placement")][SerializeField] int m_cost;
    [SerializeField] ResourceNodeType m_requiredResource;
    [Header("Electricity")]
    [SerializeField] int m_consuption;

    public string Name { get { return m_name; } }
    public string description { get { return m_description; } }
    public BuildingCategory category { get { return m_category; } }
    public int cost { get { return m_cost; } }
    public ResourceNodeType requiredResource { get { return m_requiredResource; } }
    public int consuption { get {  return m_consuption; } }
}
