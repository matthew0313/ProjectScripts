using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "RobotData", menuName = "Scriptables/Robot Data", order = 0)]public class RobotData : ScriptableObject
{
    [SerializeField] string m_name;
    [SerializeField] int m_transportCount;
    [SerializeField] float m_energyRequired;
    [SerializeField] Sprite m_image;
    public string Name { get { return m_name; } }
    public int transportCount { get { return m_transportCount; } }
    public float energyRequired { get { return m_energyRequired; } }
    public Sprite image { get { return m_image; } }
}
